NAME          HAMCK26S (CYCLES WITH STEEPEST EDGE)
ROWS
 L  R1
 L  R2
 L  R3
 N  COST
COLUMNS
    C1        R1            0.4        R2         -7.8
    C1        COST         -1.0
    C2        R1            0.2        R2         -1.4
    C2        COST        -1.75        R3        -20.0
    C3        R1           -1.4        R2          7.8
    C3        COST        12.25        R3        156.0
    C4        R1           -0.2        R2          0.4
    C4        COST          0.5        R3          8.0
RHS
    RHS       R3            1.0
ENDATA
